<p>Silence is gold.</p>
