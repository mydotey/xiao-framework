
            </div>
            <!-- // #main -->
            <div class="clear"></div>
        <!-- // #container -->
        </div>
        <div class="clear"></div>
        <div id="footer">
            <div class="copyright">Copyright &copy; 2010 AffSanctum.com</div>
            <ul class="links">
                <li><a href="#">Privacy Policy</a>
                <li class="separator">|</li>
                <li><a href="#">Disclaimer</a></li>
                <li class="separator">|</li>
                <li><a href="contactus.php">Contact Us</a></li>
                <li class="separator">|</li>
                <li><a href="#">Affiliates</a></li>
                <li class="separator">|</li>
                <li><a href="http://www.affsanctum.com/blog">Blog</a></li>
            </ul>
        </div>
    </div>
</body>
</html>
