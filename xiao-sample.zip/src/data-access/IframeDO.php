<?php
require_once dirname(realpath(__FILE__)) . "/BaseDataObject.php";

class IframeDO extends BaseDataObject
{
    private static $Table = array(
        "name" => "iframes",
        "structure" => array(
            "networkId" => "int",
            "name" => "string",
            "afterFirstSubmit" => "string",
            "firstPage" => "string",
            "secondPage" => "string",
            "firstPageRedirectTimes" => "int",
            "firstMessage" => "string",
            "secondMessage" => "string",
            "redirectPage" => "string",
            "referrerType" => "string",
            "referrer" => "string",
            "cropArea" => "object",
            "payout" => "string",
            "rand" => "string",
        ),
        "relationship" => array(
            "toOne" => array(
                "Network" => array(
                    "foreignKey" => "networkId",
                    "key" => "id",
                    "dependent" => false
                )
            ),
            "toMany" => array(
                "CampaignIframe" => array(
                    "foreignKey" => "iframeId",
                    "key" => "id",
                    "dependent" => true,
                    "plural" => "campaignsIframes"
                )
            )
        )

    );

    function __construct($dbConfig = null, $record = null, $cascade = true)
    {
        parent::__construct(self::$Table, $dbConfig, $record, $cascade);
    }
}
