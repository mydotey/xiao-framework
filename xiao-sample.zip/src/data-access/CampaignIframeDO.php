<?php
require_once dirname(realpath(__FILE__)) . "/BaseDataObject.php";

class CampaignIframeDO extends BaseDataObject
{
    private static $Table = array(
        "name" => "campaigns_iframes",
        "structure" => array(
            "campaignId" => "int",
            "iframeId" => "int"
        ),
        "relationship" => array(
            "toOne" => array(
                "Campaign" => array(
                    "foreignKey" => "campaignId",
                    "key" => "id",
                    "dependent" => false
                ),
                "Iframe" => array(
                    "foreignKey" => "iframeId",
                    "key" => "id",
                    "dependent" => false
                )
            )
        )
    );

    function __construct($dbConfig = null, $record = null, $cascade = true)
    {
        parent::__construct(self::$Table, $dbConfig, $record, $cascade);
    }
}
