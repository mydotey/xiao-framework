<?php
require_once dirname(realpath(__FILE__)) . "/BaseDataObject.php";

class CampaignDO extends BaseDataObject
{
    private static $Table = array(
        "name" => "campaigns",
        "structure" => array(
            "userId" => "int",
            "name" => "string",
            "note" => "string"
        ),
        "relationship" => array(
            "toOne" => array(
                "User" => array(
                    "foreignKey" => "userId",
                    "key" => "id",
                    "dependent" => false
                )
            ),
            "toMany" => array(
                "CampaignIframe" => array(
                    "foreignKey" => "campaignId",
                    "key" => "id",
                    "dependent" => true,
                    "plural" => "campaignsIframes"
                )
            )
        )
    );

    function __construct($dbConfig = null, $record = null, $cascade = true)
    {
        parent::__construct(self::$Table, $dbConfig, $record, $cascade);
    }
}
