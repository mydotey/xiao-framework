<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8;" />
<title><?php echo $this->getTitle(); ?></title>
<?php
$this->applyStyles();
$this->applyScripts();
?>
<!--[if IE 6]><link rel="stylesheet" type="text/css" media="screen" href="scripts/jNice/ie6.css" /><![endif]-->
<!--[if IE 7]><link rel="stylesheet" type="text/css" media="screen" href="scripts/jNice/ie7.css" /><![endif]-->
</head>
<body class="crop-page-area">
    <div id="wrapper">
        <span class="increase-page-height">
            <button id="increase-page-height" type="button">
                <span><span>Add PageHeight</span></span>
            </button>
        </span>
        <div id="wrapper-inner">
            <div id="tool-bar">
                <div id="main">
                    <fieldset>
                    <form method="post" class="jNice">
                    <?php
                    printf('<input name="%s" type="hidden" value="%s" />', "firstPage", $firstPage);
                    if($isDefault)
                        printf('<input name="%s" type="hidden" value="%s" />', "secondPage", $secondPage);
                    printf('<input name="%s" type="hidden" value="%s" />', "cropArea", $cropArea);
                    ?>
                    <p>
                        <label for="pageUrl">Page Url: </label>
                        <input id="pageUrl" type="text" value="" class="text-long" />
                        <button id="crop" type="button"><span><span>Crop</span></span></button>
                        <button id="endCrop" type="button"><span><span>Save</span></span></button>
                        <?php
                        printf('<button id="cancel" type="button" onclick="window.location=\'%s\'"><span><span>Cancel Edit</span></span></button>',
                            $this->getPage(array("action" => "edit")));
                        ?>
                        <span id="redirectTimes" class="crop">
                            <input name="firstPageRedirectTimes" id="firstPageRedirectTimes" type="hidden" value="<?php echo $firstPageRedirectTimes; ?>" />
                            <span id="loader" style="display: none"><img src="<?php echo $this->imagesUrl . "ajax-loader.gif"; ?>" alt="" /></span>
                            <script type="text/javascript">
                                var doingCorrect = false;
                                var loadingTimes = 0;
                                var correctTimeout = null;
                                function correctRedirectTimes(){
                                    if(doingCorrect)
                                        return false;
                                    else
                                    {
                                        doingCorrect = true;
                                        loadingTimes = 0;
                                        if(correctTimeout)
                                        {
                                            window.clearTimeout(correctTimeout);
                                            correctTimeout = null;
                                        }
                                    }
                                    var pageUrl = jQuery("#pageUrl").val();
                                    if(isEmpty(pageUrl))
                                    {
                                        alert("Please input the form page url.");
                                        return false;
                                    }
                                    jQuery("#loader").show();
                                    jQuery("button#crop, button#endCrop").attr("disabled", true);
                                    var iframe = jQuery("iframe.page");
                                    iframe.attr("src", blankPage + "?" + encodeURIComponent(encodeBase64(pageUrl)));
                                    correctTimeout = window.setTimeout(function(){
                                        jQuery("#firstPageRedirectTimes").val(loadingTimes - 2);
                                        correctTimeout = null;
                                        doingCorrect = false;
                                        loadingTimes = 0;
                                        jQuery("#loader").hide();
                                        jQuery("button#crop, button#endCrop").removeAttr("disabled");
                                    }, 1000 * <?php echo $this->getConfig("redirectTestTimeLimit"); ?>);
                                }
                                jQuery(document).ready(function(){
                                    jQuery("iframe.page").load(function(){
                                        if(doingCorrect)
                                        {
                                            loadingTimes++;
                                        }
                                    });
                                });
                            </script>
                        </span>
                    </p>
                    <p class="clear"></p>
                    <table id="areaInfo">
                        <tr>
                            <th>X:</th>
                            <td><input id="x" readonly="readonly" type="text" value="0" class="text-small" /></td>
                            <th>Y:</th>
                            <td><input id="y" readonly="readonly" type="text" value="0" class="text-small" /></td>
                            <th>Width:</th>
                            <td><input id="width" readonly="readonly" type="text" value="0" class="text-small" /></td>
                            <th>Height:</th>
                            <td><input id="height" readonly="readonly" type="text" value="0" class="text-small" /></td>
                        </tr>
                    </table>
                    </form>
                    <script type="text/javascript">
                        var savedTimes = 0;
                        jQuery("#increase-page-height").click(function(){
                            var increase = 200;
                            var iframe = jQuery("#page iframe.page");
                            iframe.css("height", parseInt(iframe.css("height")) + increase);
                            var overlay = jQuery("#page .overlay");
                            overlay.css("height", parseInt(overlay.css("height")) + increase);
                            var selectInstance = jQuery("#page > div.overlay").imgAreaSelect({instance: true});
                            selectInstance.update();
                        });
                        jQuery("#crop").click(function(){
                            var pageUrl = jQuery("#pageUrl");
                            var iframe = jQuery("#page > iframe.page");
                            if(isEmpty(pageUrl.val()) && isEmpty(iframe.attr("src")))
                            {
                                alert("You must designate a page to crop.");
                                return false;
                            }
                            if(!isEmpty(pageUrl.val()) && !pageUrl.attr("disabled"))
                            { 
                                if(savedTimes)
                                    iframe.attr("src", blankPage + "?" + encodeURIComponent(encodeBase64(pageUrl.val())));
                                else
                                {
                                    correctRedirectTimes();
                                }
                            }
                            jQuery("#x, #y, #width, #height").val(0);
                            desableAreaSelect();
                            enableAreaSelect();
                        });
                        jQuery("#endCrop").click(function(){
                            var result = save();
                            if(result)
                            {
                                desableAreaSelect();
                                jQuery("#x, #y, #width, #height").val(0);
                                if(currentArea == 1)
                                {
                                    restore(1);
                                }
                            }
                        });

                        var cropArea = jQuery(":hidden[name=cropArea]");
                        function serializeAreaInfo(areaInfo)
                        {
                            var result = "";
                            if(jQuery.isArray(areaInfo))
                            {
                                for(var i = 0; i < areaInfo.length; i++)
                                {
                                    if(i > 0)
                                        result += ";";
                                    result += serializeAreaInfo(areaInfo[i]);
                                }
                            }
                            else
                            {
                                result += "x=" + areaInfo.x + "," + "y=" + areaInfo.y + ","
                                    + "width=" + areaInfo.width + "," + "height=" + areaInfo.height;
                            }
                            return result;
                        }
                        function saveAreaInfo()
                        {
                            var result = {};
                            result.x = jQuery("#x").val();
                            result.y = jQuery("#y").val();
                            result.width = jQuery("#width").val();
                            result.height = jQuery("#height").val();
                            return result;
                        }
                        <?php
                        if($isDefault)
                            echo <<<html
                        var areaInfo = new Array();
                        var currentArea = 0;
                        function save()
                        {
                            var info = saveAreaInfo()
                            if(info.width == 0 || info.height == 0)
                            {
                                alert("You must create a crop area.");
                                return false;
                            }

                            areaInfo[currentArea] = info;
                            if(currentArea == 0)
                            {
                                alert("The first page area cropped has been saved. Please crop the second page.");
                                jQuery("label[for=pageUrl]").text("Second Page Url: ").css("font-weight", "bold");
                                jQuery("#crop > span > span").text("Crop");
                                jQuery(":hidden[name=firstPage]").val(jQuery("#pageUrl").val());
                                jQuery("#pageUrl").val("");
                                currentArea = 1;
                                jQuery("#endCrop > span > span").text("Save and Back");
                            }
                            else
                            {
                                alert("The second page area cropped has been saved.");
                                jQuery(":hidden[name=secondPage]").val(jQuery("#pageUrl").val());
                                cropArea.val(serializeAreaInfo(areaInfo));
                                jQuery("#tool-bar form").submit();
                            }

                            savedTimes++;
                            return true;
                        }
html;
                        else
                        {
                            echo <<<html
                        jQuery("#endCrop > span > span").text("Save and Back");
                        var areaInfo = null;
                        function save()
                        {
                            var info = saveAreaInfo()
                            if(info.width == 0 || info.height == 0)
                            {
                                alert("You must create a crop area.");
                                return false;
                            }
                            areaInfo = info;
                            alert("The page area cropped has been saved.");
                            jQuery(":hidden[name=firstPage]").val(jQuery("#pageUrl").val());
                            cropArea.val(serializeAreaInfo(areaInfo));
                            jQuery("#tool-bar form").submit();

                            savedTimes++;
                            return true;
                        }
html;
                        }
                        ?>
                    </script></fieldset>
                </div>
            </div>
            <div id="pageWrapper">
                <div id="page">
                    <script type="text/javascript">
                        var blankPage = "<?php echo $blankPage; ?>";
                    </script>
                    <iframe class="page" src="" scrolling="no" frameborder="0"></iframe>
                <div class="overlay"></div>
                </div>
            </div>
            <script type="text/javascript">
                function enableAreaSelect()
                {
                    jQuery("#page > div.overlay").css("z-index", 10).imgAreaSelect({
                            handles: true,
                            parent: "#page",
                            onSelectEnd: function(e, selection){
                                if(selection.width > 0 && selection.height > 0)
                                {
                                    jQuery("#x").val(selection.x1);
                                    jQuery("#y").val(selection.y1);
                                    jQuery("#width").val(selection.width);
                                    jQuery("#height").val(selection.height);
                                }
                            }
                    });
                }

                function desableAreaSelect()
                {
                    jQuery("#page > div.overlay").imgAreaSelect({remove: true}).css("z-index", 0);
                }
                <?php
                if($cropArea)
                {
                ?>

                function unserializeAreaInfo(strAreaInfo)
                {
                    var result = null;
                    if(strAreaInfo.indexOf(";") != -1)
                    {
                        result = new Array();
                        strAreaInfo = strAreaInfo.split(";");
                        for(var i = 0; i < strAreaInfo.length; i++)
                        {
                            result[result.length] = arguments.callee(strAreaInfo[i]);
                        }
                    }
                    else
                    {
                        result = {};
                        strAreaInfo = strAreaInfo.split(",");
                        for(var i = 0; i < strAreaInfo.length; i++)
                        {
                            var item = strAreaInfo[i].split("=");
                            result[item[0]] = parseInt(item[1]);
                        }
                    }
                    return result;
                }

                function restore(step)
                {
                    if(step == 0)
                    {
                        var firstPage = jQuery(":hidden[name=firstPage]").val();
                        if(!isEmpty(firstPage))
                        {
                            jQuery("#pageUrl").val(firstPage);
                            jQuery("#page .page").attr("src", blankPage + "?" + encodeURIComponent(encodeBase64(firstPage)));
                        }
                        else
                            return;
                    }
                    else
                    {
                        var secondPage = jQuery(":hidden[name=secondPage]").val();
                        if(!isEmpty(secondPage))
                        {
                            jQuery("#pageUrl").val(secondPage);
                            jQuery("#page .page").attr("src",  blankPage + "?" + encodeURIComponent(encodeBase64(secondPage)));
                        }
                    }
           
                    var cropAreaInfo = unserializeAreaInfo(cropArea.val());
                    if(jQuery.isArray(cropAreaInfo))
                    {
                        cropAreaInfo = cropAreaInfo[step];
                        if(!cropAreaInfo)
                            return;
                    }
                    else if(step != 0)
                        return;
                    jQuery("#x").val(cropAreaInfo.x);
                    jQuery("#y").val(cropAreaInfo.y);
                    jQuery("#width").val(cropAreaInfo.width);
                    jQuery("#height").val(cropAreaInfo.height);
                    jQuery("#page > div.overlay").css("z-index", 10).imgAreaSelect({
                            handles: true,
                            parent: "#page",
                            x1: cropAreaInfo.x,
                            y1: cropAreaInfo.y,
                            x2: cropAreaInfo.x + cropAreaInfo.width,
                            y2: cropAreaInfo.y + cropAreaInfo.height,
                            persistent: true,
                            show: true,
                            onSelectEnd: function(e, selection){
                                if(selection.width > 0 && selection.height > 0)
                                {
                                    jQuery("#x").val(selection.x1);
                                    jQuery("#y").val(selection.y1);
                                    jQuery("#width").val(selection.width);
                                    jQuery("#height").val(selection.height);
                                }
                            }
                    });
                }
                restore(0);
                <?php
                }
                ?>
            </script>
        </div>
    </div>
</body>
</html>
