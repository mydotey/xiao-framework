<?php
$id = intval($this->get("id"));
require_once $this->dataObjectsPath . "IframeDO.php";
$dataObject = new IframeDO();
$joins = array(
    "inner" => array(
        array(
            "table" => "networks",
            "alias" => "network",
            "where" => array(
                array("field" => "id", "value" => "networkId", "isJoin" => true),
                array("field" => "userId", "value" => $currentUser["id"])
            )
        )
    )
);
$dataObject->loadById(array("value" => $id, "unique" => true), "*", array(), array(), $joins);
if(!$dataObject->hasRecord())
{
    $this->setMessage("Sorry, the record you are viewing has been deleted sometime.");
    header("Location: " . $this->getPage(array(), array("action", "id")));
    exit;
}
$isDefault = $dataObject->get("afterFirstSubmit") == "default";
$cropArea = $dataObject->get("cropArea");
if($cropArea)
{
    $temp = $cropArea;
    $cropArea = "";
    foreach($temp as $item)
    {
        if($cropArea != "")
            $cropArea .= ";";
        $areaItem = "";
        foreach($item as $key => $value)
        {
            if($areaItem != "")
                $areaItem .= ",";
            $areaItem .= $key . "=" . $value;
        }
        $cropArea .= $areaItem;
    }
}
$firstPage = $dataObject->get("firstPage");
$secondPage = $dataObject->get("secondPage");
$firstPageRedirectTimes = $dataObject->get("firstPageRedirectTimes");

if($this->isPostBack())
{
    $firstPage = $this->post("firstPage");
    $cropArea = $this->post("cropArea");
    if($cropArea)
    {
        $areaInfo = explode(";", $cropArea);
        $cropArea = array();
        foreach($areaInfo as $item)
        {
            $item = trim($item);
            $info = array();
            if($item)
            {
                $dimInfo = explode(",", $item);
                foreach($dimInfo as $item2)
                {
                    $dim = explode("=", $item2);
                    $info[$dim[0]] = $dim[1];
                }
            }
            $cropArea[] = $info;
        }
        if(!$isDefault)
        {
            unset($cropArea[1]);
        }
    }
    $firstPageRedirectTimes = $this->post("firstPageRedirectTimes");
    $secondPage = "";
    if($isDefault)
    {
        $secondPage = $this->post("secondPage");
    }
    $dataObject->set(compact("firstPage", "cropArea", "firstPageRedirectTimes", "secondPage"));
    $dataObject->save();
    $this->setMessage("The crop info has been saved.");
    header("Location: " . $this->getPage(array(), array("action", "id")));
    exit;
}

$this->setData(compact("isDefault", "cropArea", "firstPage", "secondPage", "firstPageRedirectTimes"));

$this->styles["imgAreaSelect"] = "imgAreaSelect/imgareaselect-default.css";
$this->scripts["imgAreaSelect"] = "jquery.imgareaselect.pack.js";
$this->notUseTemplate();

$this->setData("blankPage", $this->utilitiesUrl . "blank.php");
