<?php
require_once $this->dataObjectsPath . "UserDO.php";
$userDO = new UserDO();
$userDO->set("id", $currentUser["id"]);
$networks = $userDO->loadRelatedNetworks(array("id", "name"));

if($this->isPostBack())
{
    require_once $this->dataObjectsPath . "IframeDO.php";
    $dataObject = new IframeDO();

    $name = $this->post("name");
    $networkId = $this->post("networkId");
    $payout = $this->post("payout");
    $referrerType = $this->post("referrerType");
    $referrer = $this->post("referrer");
    if($referrerType != "fake")
        $referrer = "";
    $afterFirstSubmit = $this->post("afterFirstSubmit");
    $firstMessage = trim($this->post("firstMessage"));
    $secondMessage = trim($this->post("secondMessage"));
    if($afterFirstSubmit != "default")
        $secondMessage = "";
    $redirectPage = $this->post("redirectPage");
    if(in_array($afterFirstSubmit, array("fullPage", "hide")))
    {
        $redirectPage = "";
    }

    $joins = array(
        "inner" => array(
            array(
                "table" => "networks",
                "alias" => "network",
                "where" => array(
                    array("field" => "id", "value" => "networkId", "isJoin" => true),
                    array("field" => "userId", "value" => $currentUser["id"])
                )
            )
        )
    );
    $dataObject->loadByName(array("value" => $name, "unique" => true),
        array("field" => "id"), null, null, $joins);
    if($dataObject->hasRecord())
    {
        $this->setMessage("Iframe name has been exsitent.");
        $this->setData(compact("name", "networkId", "payout", "afterFirstSubmit",
            "firstMessage", "secondMessage", "redirectPage", "referrerType", "referrer"));
    }
    else
    {
        $rand = CommonTools::generateRandomString();
        $record = compact("name", "networkId", "payout", "afterFirstSubmit", "rand",
            "firstMessage", "secondMessage", "redirectPage", "referrerType", "referrer");
        $dataObject->set($record);
        $dataObject->save();

        header("Location: " . $this->getPage(array("action" => "crop", "id" => $dataObject->get("id"))));
        exit;
    }
}

$this->setData(compact("networks"));
