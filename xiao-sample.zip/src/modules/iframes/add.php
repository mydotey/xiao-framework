<h3>Add New Iframe</h3>
<fieldset>
    <form method="post" class="jNice">
        <p>
            <label for="name">Name: </label>
            <input name="name" id="name" type="text" value="<?php echo $this->getData("name"); ?>" class="text-long" />
        </p>
        <p>
            <label for="networkId">Network: </label>
            <select name="networkId">
                <option value="0">Please select</option>
                <?php
                foreach($networks as $item)
                    printf('<option value="%s"%s>%s</option>', $item["id"],
                        $item["id"] == $this->getData("networkId") ? ' selected="selected"' : "", $item["name"]);
                ?>
            </select>
        </p>
        <p class="field">
            <label for="payout">Payout: </label>
            <input name="payout" id="payout" type="text" value="<?php echo $this->getData("payout"); ?>" class="text-small" />
        </p>
        <p>
            <label>Referrer Type:</label>
            <select id="referrerType" name="referrerType" onchange="referrerType_change();">
                <?php
                $referrerTypes = array(
                    "blank" => "Blank Referrer",
                    "fake" => "Fake Referrer",
                    "default" => "Pass",
                );
                foreach($referrerTypes as $key => $value)
                    printf('<option value="%s"%s>%s</option>', $key,
                        $key == $this->getData("referrerType") ? ' selected="selected"' : "", $value
                    );
                ?>
            </select>
        </p>
        <p<?php if($this->getData("referrerType") != "fake") echo ' style="display: none;"'; ?>>
            <label for="referrer">Referrer</label>
            <input name="referrer" id="referrer" type="text" class="text-long" value="<?php echo $this->getData("referrer"); ?>" />
        </p>
        <script type="text/javascript">
            function referrerType_change()
            {
                var value = jQuery("#referrerType").val();
                if(value == "fake")
                    jQuery("#referrer").parent().show();
                else
                    jQuery("#referrer").parent().hide();
            }
        </script>
        <p>
            <label>After First Submit:</label>
            <select name="afterFirstSubmit" onchange="afterFirstSubmit_change();">
                <?php
                $afterFirstSubmit = array(
                    "default" => "Default",
                    "fullPage" => "Full Page",
                    "redirect" => "Redirect",
                    "hide" => "Hide"
                );
                foreach($afterFirstSubmit as $key => $value)
                    printf('<option value="%s"%s>%s</option>', $key,
                        $key == $this->getData("afterFirstSubmit") ? ' selected="selected"' : "", $value
                    );
                ?>
            </select>
        </p>
        <p>
            <label>Popup Text after First Submit:</label>
            <input type="text" name="firstMessage" value="<?php echo $this->getData("firstMessage"); ?>" class="text-long" />
            <span class="field-desc">Empty means none.</span>
        </p>
        <p>
            <label>After Second Submit:</label>
            <select name="afterSecondSubmit" onchange="afterSecondSubmit_change();">
                <?php
                $afterSecondSubmit = array(
                    "redirect" => "Redirect",
                    "hide" => "Hide"
                );
                $selectedValue = $this->getData("redirectPage") ? "redirect" : "hide";
                foreach($afterSecondSubmit as $key => $value)
                    printf('<option value="%s"%s>%s</option>', $key,
                        $key == $selectedValue ? ' selected="selected"' : "", $value
                    );
                ?>
            </select>
        </p>
        <p>
            <label>Popup Text after Second Submit: </label>
            <input type="text" name="secondMessage" value="<?php echo $this->getData("secondMessage"); ?>" class="text-long" />
            <span class="field-desc">Empty means none.</span>
        </p>
        <p>
            <label>Redirect Url:</label>
            <input name="redirectPage" id="redirectPage" type="text" class="text-long" value="<?php echo $this->getData("redirectPage"); ?>" />
        </p>
        <script type="text/javascript">
            function afterFirstSubmit_change()
            {
                var value = jQuery("select[name=afterFirstSubmit]").val();
                if(value == "default")
                {
                    jQuery("#redirectPage").parent().show();
                    jQuery(":text[name=secondMessage]").parent().show();
                    jQuery("select[name=afterSecondSubmit]").parents("p").show();
                }
                else
                {
                    jQuery("select[name=afterSecondSubmit]").parents("p").hide();
                    if(value == "redirect")
                        jQuery(":text[name=redirectPage]").parent().show();
                    else
                        jQuery(":text[name=redirectPage]").parent().hide();
                    jQuery(":text[name=secondMessage]").parent().hide();
                }
            }
            function afterSecondSubmit_change()
            {
                var value = jQuery("select[name=afterSecondSubmit]").val();
                if(value == "redirect")
                    jQuery("#redirectPage").parent().show();
                else
                {
                    jQuery("#redirectPage").parent().hide();
                    jQuery(":text[name=redirectPage]").val("");
                }
            }
            jQuery(document).ready(function(){
                jQuery("select[name=afterFirstSubmit]").change();
                jQuery("select[name=afterSecondSubmit]").change();
            });
        </script>
        <p class="submit"><input type="submit" value="Add and Crop" /></p>
    </form>
    <script type="text/javascript">
        jQuery("form").bind("submit", function(){
            if(isEmpty(jQuery("#name").val()))
            {
                alert("Iframe name could not be empty.");
                return false;
            }
            if(jQuery("select[name=networkId]").val() == 0)
            {
                alert("Iframe network could not be empty.");
                return false;
            }
            if((jQuery("select[name=afterFirstSubmit]").val() == "default"
                && jQuery("select[name=afterSecondSubmit]").val() == "redirect"
                || jQuery("select[name=afterFirstSubmit]").val() == "redirect"
                )
                && isEmpty(jQuery(":text[name=redirectPage]").val())
            )
            {
                alert("Redirect Url not be empty.");
                return false;
            }
        });
    </script>
</fieldset>
