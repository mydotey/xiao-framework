<?php
require_once $this->dataObjectsPath . "UserDO.php";
$userDO = new UserDO();
$userDO->set("id", $currentUser["id"]);
$networks = $userDO->loadRelatedNetworks(array("id", "name"));

require_once $this->dataObjectsPath . "IframeDO.php";
$dataObject = new IframeDO();
$id = intval($this->get("id"));
$joins = array(
    "inner" => array(
        array(
            "table" => "networks",
            "alias" => "network",
            "where" => array(
                array("field" => "id", "value" => "networkId", "isJoin" => true),
                array("field" => "userId", "value" => $currentUser["id"])
            )
        )
    )
);
$dataObject->loadById(array("value" => $id, "unique" => true), "*", array(), array(), $joins);
if(!$dataObject->hasRecord())
{
    $this->setMessage("Sorry. The record you are editting has been deleted sometime.");
    header("Location: " . $this->getPage(array(), array("action", "id")));
    exit;
}

$name = $dataObject->get("name");
$networkId = $dataObject->get("networkId");
$payout = $dataObject->get("payout");
$referrerType = $dataObject->get("referrerType");
$referrer = $dataObject->get("referrer");
$afterFirstSubmit = $dataObject->get("afterFirstSubmit");
$firstMessage = trim($dataObject->get("firstMessage"));
$secondMessage = trim($dataObject->get("secondMessage"));
$redirectPage = $dataObject->get("redirectPage");

if($this->isPostBack())
{
    $network = $this->post["networkId"];
    $payout = trim($this->post["payout"]);
    $referrerType = $this->post("referrerType");
    $referrer = $this->post("referrer");
    if($referrerType != "fake")
        $referrer = "";

    $oldAfterFirstSubmit = $afterFirstSubmit;
    $afterFirstSubmit = $this->post("afterFirstSubmit");
    $needCrop = false;
    if($oldAfterFirstSubmit == "default" && $afterFirstSubmit != "default" 
        || $oldAfterFirstSubmit != "default" && $afterFirstSubmit == "default"
    )
        $needCrop = true;

    $firstMessage = trim($this->post("firstMessage"));
    $secondMessage = trim($this->post("secondMessage"));
    if($afterFirstSubmit != "default")
        $secondMessage = "";
    $redirectPage = $this->post("redirectPage");
    if(in_array($afterFirstSubmit, array("fullPage", "hide")))
    {
        $redirectPage = "";
    }

    $dataObject->set(compact("networkId", "payout", "referrerType", "referrer",
        "afterFirstSubmit", "firstMessage", "secondMessage", "redirectPage"));
    $dataObject->save();

    if($needCrop)
        header("Location: " . $this->getPage(array("action" => "crop")));
    else
    {
        $this->setMessage("The record has been saved.");
        header("Location: " . $this->getPage(array(), array("action", "id")));
    }
    exit;
}

$this->setData(compact("networks", "name", "networkId", "payout", "referrerType", "referrer",
    "afterFirstSubmit", "firstMessage", "secondMessage", "redirectPage"));
