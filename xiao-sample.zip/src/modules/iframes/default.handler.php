<?php
require_once $this->dataObjectsPath . "IframeDO.php";
$dataObject = new IframeDO();

$joins = array(
    "inner" => array(
        array(
            "table" => "networks",
            "alias" => "network",
            "where" => array(
                array("field" => "id", "value" => "networkId", "isJoin" => true),
                array("field" => "userId", "value" => $currentUser["id"])
            )
        )
    )
);

if($this->get("id"))
{
    $dataObject->loadById(array("value" => $this->get("id"), "unique" => true), array("id"),
        null, null, $joins);
    $dataObject->delete();
    $this->setMessage("The record has been deleted.");
    header("Location: " . $this->getPage(array(), array("id")));
    exit;
}

$where = array();
$search = trim($this->get("search"));
if($search)
{
    $where[] = array("field" => "name", "value" => "%$search%", "operator" => "like");
    $this->setData("search", $search);
}
$recordCount = $dataObject->count($where, $joins);
$paginationInfo = $this->preparePagination($recordCount);
$orderBy = $this->prepareOrders();
$records = $dataObject->loadAll($paginationInfo["page"],
    $paginationInfo["pageSize"], null, $where, $orderBy, $joins);
$this->setData("records", $records);
