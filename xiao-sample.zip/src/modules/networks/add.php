<h3>Add New Network</h3>
<fieldset>
    <form method="post" class="jNice">
        <p>
            <label for="name">Name: </label>
            <input name="name" id="name" type="text" value="<?php echo $this->getData("name"); ?>" class="text-long" />
        </p>
        <p>
            <label for="note">Note: </label>
            <textarea id="note" name="note"><?php echo $this->getData("note"); ?></textarea>
        </p>
        <p class="submit"><input type="submit" value="Add" /></p>
    </form>
    <script type="text/javascript">
        jQuery("form").bind("submit", function(){
            if(isEmpty(jQuery("#name").val()))
            {
                alert("Network name could not be empty.");
                return false;
            }
        });
    </script>
</fieldset>
