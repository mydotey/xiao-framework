<?php
require_once $this->dataObjectsPath . "NetworkDO.php";
$dataObject = new NetworkDO();
$id = intval($this->get("id"));
$dataObject->loadById(array("value" => $id, "unique" => true), "*",
    array("field" => "userId", "value" => $currentUser["id"]));
if(!$dataObject->hasRecord())
{
    $this->setMessage("Sorry. The record you are editting has been deleted sometime.");
    header("Location: " . $this->getPage(array(), array("action", "id")));
    exit;
}

$this->setData($dataObject->get());

require_once $this->dataObjectsPath . "IframeDO.php";
$iframeDO = new IframeDO();
$where = array("field" => "networkId", "value" => $id);
$recordCount = $iframeDO->count($where);
$paginationInfo = $this->preparePagination($recordCount);
$orderBy = $this->prepareOrders();
$relatedIframes = $iframeDO->loadAll($paginationInfo["page"], $paginationInfo["pageSize"],
    array("id", "name", "created"), null, $orderBy
);

$this->setData(compact("relatedIframes"));
