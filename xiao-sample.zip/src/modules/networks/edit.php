<h3>Edit Network</h3>
<fieldset>
    <form method="post" class="jNice">
        <p>
            <label>Name: </label>
            <input type="text" value="<?php echo $name; ?>" disabled="disabled" class="text-long" />
        </p>
        <p>
            <label for="note">Note: </label>
            <textarea id="note" name="note"><?php echo $note; ?></textarea>
        </p>
        <p class="submit"><input type="submit" value="Save" /></p>
    </form>
</fieldset>
