<h3>Network - <em><?php echo $name; ?></em></h3>
<p class="note"><?php echo $note; ?></p>
<h3>Iframes</h3>
<?php
if(count($relatedIframes) > 0)
{
    ?>
<table>
	<thead>
		<tr>
			<th class="number">Number</th>
			<th><a href="<?php echo $this->generateOrderLink("name"); ?>">Name</a></th>
			<th class="date"><a href="<?php echo $this->generateOrderLink("created"); ?>">Created</a></th>
		</tr>
	</thead>
	<tbody>
	<?php
	for($i = 0; $i < count($relatedIframes); $i++)
	{
	    printf('<tr%s><td>%s</td><td>%s</td><td>%s</td></tr>', ($i + 1) % 2 == 0 ? ' class="odd"' : '',
            ($page - 1) * $pageSize + $i + 1, $relatedIframes[$i]["name"], $relatedIframes[$i]["created"]
	    );
	}
	?>
	</tbody>
</table>
	<?php
    $this->showPagination();
}
else
{
?>
<fieldset class="empty-data">
    <p>There are no related iframes currently.</p>
</fieldset>
<?php
}

?>
