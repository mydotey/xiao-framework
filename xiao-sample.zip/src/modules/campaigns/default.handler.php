<?php
require_once $this->dataObjectsPath . "CampaignDO.php";
$dataObject = new CampaignDO();

if($this->get("id"))
{
    $dataObject->loadById(array("value" => $this->get("id"), "unique" => true), array("id"),
        array("field" => "userId", "value" => $currentUser["id"]));
    $dataObject->delete();
    $this->setMessage("The record has been deleted.");
    header("Location: " . $this->getPage(array(), array("id")));
    exit;
}

$where = array(
    array("field" => "userId", "value" => $currentUser["id"])
);
$search = trim($this->get("search"));
if($search)
{
    $where[] = array("field" => "name", "value" => "%$search%", "operator" => "like");
    $this->setData("search", $search);
}
$recordCount = $dataObject->count($where);
$paginationInfo = $this->preparePagination($recordCount);
$orderBy = $this->prepareOrders();
$records = $dataObject->loadAll($paginationInfo["page"], $paginationInfo["pageSize"], null,
    $where, $orderBy);
$this->setData("records", $records);
