<?php
require_once $this->dataObjectsPath . "CampaignIframeDO.php";
$campaignIframeDO = new CampaignIframeDO();
$campaignIframeDO->delete(
    array(
        array("field" => "campaignId", "value" => $this->get("id")),
        array("field" => "iframeId", "value" => $this->get("iframe-id"))
    ),
    array(
        "inner" => array(
            array(
                "table" => "iframes",
                "alias" => "iframe",
                "where" => array(
                    array("field" => "id", "value" => "iframeId", "isJoin" => true)
                )
            ),
            array(
                "table" => "networks",
                "alias" => "network",
                "where" => array(
                    array("field" => "id", "value" => "networkId", "isJoin" => true, "join-table-alias" => "iframe"),
                    array("field" => "userId", "value" => $currentUser["id"])
                )
            )
        )
    )
);
$this->setMessage("Iframe removed.");
header("Location: " . $this->getPage(array("action" => "view"), array("iframe-id")));
exit;
