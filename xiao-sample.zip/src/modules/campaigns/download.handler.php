<?php
require_once $this->dataObjectsPath . "CampaignDO.php";
$dataObject = new CampaignDO();
$id = intval($this->get("id"));
$dataObject->loadById(array("value" => $id, "unique" => true), "*",
    array("field" => "userId", "value" => $currentUser["id"]));
if(!$dataObject->hasRecord())
{
    $this->setMessage("Sorry. The record has been deleted sometime.");
    header("Location: " . $this->getPage(array(), array("action", "id")));
    exit;
}

require_once $this->dataObjectsPath . "IframeDO.php";
$iframeDO = new IframeDO();
$joins = array(
    "inner" => array(
        array(
            "table" => "campaigns_iframes",
            "alias" => "campaign_iframe",
            "where" => array(
                array("field" => "iframeId", "value" => "id", "isJoin" => true)
            )
        ),
        array(
            "table" => "campaigns",
            "alias" => "campaign",
            "where" => array(
                array("field" => "id", "value" => "campaignId", "isJoin" => true, "join-table-alias" => "campaign_iframe"),
                array("field" => "id", "value" => $id)
            )
        )
    )
);
$relatedIframes = $iframeDO->loadAll(null, null, null, null, null, $joins);

require_once $this->businessObjectsPath . "CodeStuffer.php";
$codes = array();
$iframeCodes = array();
foreach($relatedIframes as $item)
{
    $codeStuffer = new CodeStuffer($item, $this->utilitiesUrl . "blank.php");
    $iframeCodes[] = CommonTools::minimumBlankChars($codeStuffer->stuffCode());
    if($item["referrerType"] == "fake")
    {
        $referrerCode = $codeStuffer->stuffReferrerCode();
        $referrerCode = $referrerCode;
        $fileName = "fakereferrer-" . CommonTools::filterSpecialChar($item["name"]) . ".php";
        $codes[$fileName] = $referrerCode;
    }
}

$randomCode = '<?php
$campaignCodes = array();
';
foreach($iframeCodes as $item)
{
    $randomCode .= <<<code
\$campaignCodes[] = <<<htmlCode
$item
htmlCode;

code;
}
$randomCode .= 'echo $campaignCodes[rand(0, count($campaignCodes) - 1)];
?>';
$fileName = CommonTools::filterSpecialChar($dataObject->get("name")) . ".php";
$codes = array_merge(array($fileName => $randomCode), $codes);

require_once $this->libsPath . "zip.php";
$zipper = new zipfile();
foreach($codes as $key => $value)
{
    $zipper->addFile($value, $key);
}
$zipFile = $zipper->file();

if($this->get("download"))
{
    header("Content-type: application/octet-stream");
    header("Content-disposition: attachment; filename=" . CommonTools::filterSpecialChar($dataObject->get("name")) . ".zip");
    echo $zipFile;

    exit;
}
else
    $this->setData(compact("codes"));
