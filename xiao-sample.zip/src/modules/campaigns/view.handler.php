<?php
require_once $this->dataObjectsPath . "CampaignDO.php";
$dataObject = new CampaignDO();
$id = intval($this->get("id"));
$dataObject->loadById(array("value" => $id, "unique" => true), "*",
    array("field" => "userId", "value" => $currentUser["id"]));
if(!$dataObject->hasRecord())
{
    $this->setMessage("Sorry. The record you are viewing has been deleted sometime.");
    header("Location: " . $this->getPage(array(), array("action", "id")));
    exit;
}
$this->setData($dataObject->get());

require_once $this->dataObjectsPath . "IframeDO.php";
$iframeDO = new IframeDO();
if($this->post("addIframe") !== null)
{
    require_once $this->dataObjectsPath . "CampaignIframeDO.php";
    $campaignIframeDO = new CampaignIframeDO();
    $campaignIframeDO->loadByCampaignId(array("value" => $id, "unique" => true), null,
        array("field" => "iframeId", "value" => $this->post["iframeId"]));
    if(!$campaignIframeDO->hasRecord())
    {
        $campaignIframeDO->set(array("campaignId" => $id, "iframeId" => $this->post["iframeId"]));
        $campaignIframeDO->save();
        $this->setMessage("Iframe added.");
    }
}
$joins = array(
    "inner" => array(
        array(
            "table" => "campaigns_iframes",
            "alias" => "campaign_iframe",
            "where" => array(
                array("field" => "iframeId", "value" => "id", "isJoin" => true)
            )
        ),
        array(
            "table" => "campaigns",
            "alias" => "campaign",
            "where" => array(
                array("field" => "id", "value" => "campaignId", "isJoin" => true, "join-table-alias" => "campaign_iframe"),
                array("field" => "id", "value" => $id)
            )
        )
    )
);
$iframeCount = $iframeDO->count(null, $joins);
$paginationInfo = $this->preparePagination($iframeCount);
$orderBy = $this->prepareOrders();
$relatedIframes = $iframeDO->loadAll($paginationInfo["page"], $paginationInfo["pageSize"],
    array(array("field" => "id"), array("field" => "name"), array("field" => "created",
    "table-alias" => "campaign_iframe", "alias" => "added")), null, $orderBy, $joins
);

$relatedIframeIds = array();
foreach($relatedIframes as $item)
{
    $relatedIframeIds[] = $item["id"];
}
$where = array(
    "field" => "id", "operator" => "not in", "value" => $relatedIframeIds
);
$joins = array(
    "inner" => array(
        array(
            "table" => "networks",
            "alias" => "network",
            "where" => array(
                array("field" => "id", "value" => "networkId", "isJoin" => true),
                array("field" => "userId", "value" => $currentUser["id"])
            )
        )
    )
);
$iframes = $iframeDO->loadAll(null, null, array("id", "name"), $where, null, $joins);

$this->setData(compact("relatedIframes", "iframes"));
