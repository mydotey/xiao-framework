<?php
if($this->isPostBack())
{
    require_once $this->dataObjectsPath . "CampaignDO.php";
    $dataObject = new CampaignDO();

    $name = $this->post("name");
    $note = $this->post("note");
    $userId = $currentUser["id"];

    $dataObject->loadByName(array("value" => $name, "unique" => true),
        array("field" => "id"), array("field" => "userId", "value" => $userId));
    if($dataObject->hasRecord())
    {
        $this->setMessage("Campaign name has been exsitent.");
        $this->setData(compact("name", "note"));
    }
    else
    {
        $record = compact("name", "note", "userId");
        $dataObject->set($record);
        $dataObject->save();

        $this->setMessage("The record has been added.");
        header("Location: " . $this->getPage(array("action" => "view", "id" => $dataObject->get("id"))));
        exit;
    }
}
