<p style="float: right;">
    <a href="<?php echo $this->getPage(array("action" => "download"), array("order")); ?>">Get Code</a>
</p>
<h3>Edit Campaign</h3>
<fieldset>
    <form method="post" class="jNice">
        <p>
            <label>Name: </label>
            <input type="text" value="<?php echo $name; ?>" disabled="disabled" class="text-long" />
        </p>
        <p>
            <label for="note">Note: </label>
            <textarea id="note" name="note"><?php echo $note; ?></textarea>
        </p>
        <p class="submit"><input type="submit" name="saveCampaign" value="Save" /></p>
    </form>
</fieldset>
