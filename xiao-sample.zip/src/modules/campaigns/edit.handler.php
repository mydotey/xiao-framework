<?php
require_once $this->dataObjectsPath . "CampaignDO.php";
$dataObject = new CampaignDO();
$id = intval($this->get("id"));
$dataObject->loadById(array("value" => $id, "unique" => true), "*",
    array("field" => "userId", "value" => $currentUser["id"]));
if(!$dataObject->hasRecord())
{
    $this->setMessage("Sorry. The record you are editting has been deleted sometime.");
    header("Location: " . $this->getPage(array(), array("action", "id")));
    exit;
}

$name = $dataObject->get("name");
$note = $dataObject->get("note");

if($this->post("saveCampaign") !== null)
{
    $note = trim($this->post["note"]);

    $dataObject->set(compact("note"));
    $dataObject->save();

    $this->setMessage("The record has been saved.");
    header("Location: " . $this->getPage(array(), array("action", "id")));
    exit;
}

$this->setData(compact("name", "note"));
