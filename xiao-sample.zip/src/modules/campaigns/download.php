<p style="float: right;">
    <a href="<?php echo $this->getPage(array("download" => "true"), array("order")); ?>">Download</a>
</p>
<h3>Get Code</h3>
<?php
foreach($codes as $key => $value)
{
    echo <<<code
<div class="code-wrapper">
    <p class="title">{$key}</p>
    <p class="code">
        <textarea readonly="readonly">{$value}</textarea>
    </p>
</div>
code;
}
?>
<script type="text/javascript">
    function select()
    {
        this.select();
    }
    jQuery(".code-wrapper textarea").mouseover(select).focus(select);
</script>
