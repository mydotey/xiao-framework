<p style="float: right;">
    <a href="<?php echo $this->getPage(array("action" => "download"), array("order")); ?>">Get Code</a>
</p>
<h3>Campain - <em><?php echo $name; ?></em></h3>
<p class="note"><?php echo $note; ?></p>
<h3>Iframes</h3>
<form method="post" class="jNice">
<div class="add-iframe">
    <select name="iframeId">
        <option value="0">Please Select</option>
        <?php
        foreach($iframes as $item)
            printf('<option value="%s">%s</option>', $item["id"], $item["name"]);
        ?>
    </select>
    <input type="submit" name="addIframe" value="Add" />
</div>
</form>
<?php
if(count($relatedIframes) > 0)
{
    ?>
<table>
	<thead>
		<tr>
			<th class="number">Number</th>
			<th>Name</th>
			<th class="date">Added</th>
			<th style="width: 100px;">Operations</th>
		</tr>
	</thead>
	<tbody>
	<?php
	for($i = 0; $i < count($relatedIframes); $i++)
	{
	    printf('<tr%s><td>%s</td><td>%s</td><td>%s</td><td>
            <a href="%s" onclick="return confirm(\'Are you sure you want to remove it?\');">Remove</a>
            </td></tr>', ($i + 1) % 2 == 0 ? ' class="odd"' : '',
            ($page - 1) * $pageSize + $i + 1, $relatedIframes[$i]["name"], $relatedIframes[$i]["added"],
            $this->getPage(array("action" => "remove-iframe", "iframe-id" => $relatedIframes[$i]["id"]))
	    );
	}
	?>
	</tbody>
</table>
	<?php
    $this->showPagination();
}
else
{
?>
<fieldset class="empty-data">
    <p>There are no related iframes currently.</p>
</fieldset>
<?php
}
?>
