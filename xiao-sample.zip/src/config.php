<?php
$config = array(
    // Database
    "dbConfig" => array(
        "server" => "localhost",
        "user" => "root",
        "password" => "",
        "name" => "cpa_new"
    ),
    // Install Settings - Available at Installation Only
    "install" => array(
        "admin-login" => "admin",
        "admin-password" => "123456",
        "admin-email" => "master@site.com",
        "admin-capabilities" => array(
            "dashboard", "users"
        )
    ),

    // Debug
    "debug" => true,
    "displayErrors" => true,
    "errorReporting" => E_ERROR | E_WARNING | E_PARSE | E_NOTICE, // or E_ALL

    // Site
    "webRoot" => "http://xiao/CPA-New/source",
    "title" => "ExtremeCPA",
    "redirectTestTimeLimit" => 5,

    // Modules
    // menuOrder is required, and unique. an action also may be a main menu item if has a attribute "asMainMenu" with value true.
    "modules" => array(
        "users" => array(
            "title" => "Users",
            "capability" => "users",
            "menuOrder" => 0,
            "actions" => array(
                "default" => array(
                    "title" => "User List",
                    "asSubMenu" => true,
                    "menuOrder" => 0
                ),
                "add" => array(
                    "title" => "Add User",
                    "asSubMenu" => true,
                    "menuOrder" => 1
                ),
                "edit" => array(
                    "title" => "Edit User"
                ),
                "login" => array(
                    "title" => "Log In",
                    "capability" => "anonymous"
                ),
                "logout" => array(
                    "title" => "Log Out",
                    "capability" => "anonymous"
                )
            )
        ),
        "dashboard" => array(
            "title" => "Dashboard",
            "capability" => "dashboard",
            "menuOrder" => 100,
            "actions" => array(
                "default" => array(
                    "title" => "Account Info",
                    "asSubMenu" => true,
                    "menuOrder" => 0
                ),
                "change-password" => array(
                    "title" => "Change Password",
                    "asSubMenu" => true,
                    "menuOrder" => 1
                ),
            )
        ),
        "networks" => array(
            "title" => "Networks",
            "capability" => "networks",
            "menuOrder" => 10,
            "actions" => array(
                "default" => array(
                    "title" => "Networks",
                    "asSubMenu" => true,
                    "menuOrder" => 0
                ),
                "add" => array(
                    "title" => "Add Network",
                    "asSubMenu" => true,
                    "menuOrder" => 1
                ),
                "edit" => array(
                    "title" => "Edit Network"
                ),
                "view" => array(
                    "title" => "View Network"
                ),
            )
        ),
        "iframes" => array(
            "title" => "Iframes",
            "capability" => "iframes",
            "menuOrder" => 20,
            "actions" => array(
                "default" => array(
                    "title" => "Iframes",
                    "asSubMenu" => true,
                    "menuOrder" => 0
                ),
                "add" => array(
                    "title" => "Add Iframes",
                    "asSubMenu" => true,
                    "menuOrder" => 1
                ),
                "edit" => array(
                    "title" => "Edit Iframe"
                ),
                "crop" => array(
                    "title" => "Crop Page Area"
                )
            )
        ),
        "campaigns" => array(
            "title" => "Campaigns",
            "capability" => "campaigns",
            "menuOrder" => 30,
            "actions" => array(
                "default" => array(
                    "title" => "Campaigns",
                    "asSubMenu" => true,
                    "menuOrder" => 0
                ),
                "add" => array(
                    "title" => "Add Campaigns",
                    "asSubMenu" => true,
                    "menuOrder" => 1
                ),
                "edit" => array(
                    "title" => "Edit Campaigns"
                ),
                "view" => array(
                    "title" => "View Campaigns"
                )
            )
        )
    ),

    // Default Page
    "defaultPage" => array(
        "users" => array("module" => "users"),
        "settings" => array("module" => "settings"),
        "campaigns" => array("module" => "campaigns"),
        "iframes" => array("module" => "iframes"),
        "networks" => array("module" => "networks"),
        "dashboard" => array("module" => "dashboard"),
        "anonymous" => array("module" => "users", "action" => "login")
    ),

    // Paging
    "pageSize" => 30,
);
