<html>
<head>
<?php
if(!empty($_GET))
{
    foreach($_GET as $key => $item)
    {
        $page = $key;
        break;
    }
    $ua = $_SERVER['HTTP_USER_AGENT'];
    $useRefererUs = false;
    $browserNames = array("chrome", "safari", "webkit");
    foreach($browserNames as $item)
    {
        if(stripos($ua, $item) !== false)
        {
            $useRefererUs = true;
            break;
        }
    }
    $page = base64_decode($page);
    if(!$useRefererUs)
    {
        printf('<meta http-equiv="refresh" content="%s;url=%s" />', 0, $page);
    }
    else
    {
        if(stripos($page, "https"))
            $page = substr($page, 8);
        else if(stripos($page, "http"))
            $page = substr($page, 7);
        echo  <<<script
<script type="text/javascript">
    location.href = "http://referer.us/$page";
</script>
script;
    }
}
?>
<title></title>
</head>
<body>
</body>
</html>
