<p id="message">Sorry. The page you are visiting is not found.</p>
<p>
    <a href="index.php">Back to Use</a>
</p>
