<?php
require_once "Page.php";
$appRoot = dirname(realpath(__FILE__)) . "/";
$scripts = array(
    "base64" => "base64.min.js",
    "DD_roundies" => "DD_roundies_0.0.2a-min.js"
);
$page = new Page($appRoot, array(), $scripts);
$page->init();
$page->handleBusiness();
$page->render();
